package com.samsung.hass

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.w3c.dom.Element
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

class MainActivity : ComponentActivity() {
    private var selectedTar: Uri? = null
    private var selectedBin: Uri? = null
    private var outputMode = "unpack"
    private lateinit var status: TextView
    private lateinit var tarLabel: TextView
    private lateinit var binLabel: TextView

    private val openTar = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { selectedTar = uri; contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); tarLabel.text = "ملف الحزمة: ${nameOf(uri)}"; status.text = "تم اختيار ملف TAR" }
    }
    private val openBin = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { selectedBin = uri; contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); binLabel.text = "ملف BIN: ${nameOf(uri)}"; status.text = "تم اختيار ملف BIN" }
    }
    private val saveResult = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) runCatching { writeUnpackedZip(uri) }.onSuccess { status.text = "اكتمل فك الضغط والفحص. تم حفظ ملفات BIN داخل ZIP." }.onFailure { showError(it) }
    }
    private val saveTar = registerForActivityResult(ActivityResultContracts.CreateDocument("application/x-tar")) { uri ->
        if (uri != null) runCatching { writePackedTar(uri) }.onSuccess { status.text = "اكتمل الضغط وإعادة التجميع والتحقق الداخلي." }.onFailure { showError(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 20); layoutDirection = ViewGroup.LAYOUT_DIRECTION_RTL; setBackgroundColor(0xFFF4F7FB.toInt()) }
        val title = TextView(this).apply { text = "Samsung HASS"; textSize = 27f; setTextColor(0xFF12345A.toInt()); gravity = Gravity.CENTER; setPadding(0, 8, 0, 4) }
        val subtitle = TextView(this).apply { text = "أداة فك وضغط وفحص Firmware"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(0xFF536579.toInt()); setPadding(0, 0, 0, 22) }
        root.addView(title); root.addView(subtitle)
        tarLabel = label("لم يتم اختيار ملف TAR")
        binLabel = label("لم يتم اختيار ملف BIN")
        root.addView(tarLabel); root.addView(actionButton("اختيار ملف تحديث TAR / TGZ") { openTar.launch(arrayOf("application/*", "*/*")) })
        root.addView(binLabel); root.addView(actionButton("اختيار ملف Firmware BIN") { openBin.launch(arrayOf("application/octet-stream", "*/*")) })
        root.addView(actionButton("فك الضغط + فحص CRC + استخراج BIN") { if (selectedTar == null) status.text = "اختر ملف TAR أولاً" else { outputMode = "unpack"; saveResult.launch("HASS_extracted.zip") } })
        root.addView(actionButton("ضغط BIN وإعادة إنشاء TAR") { if (selectedBin == null) status.text = "اختر ملف BIN أولاً" else { outputMode = "pack"; saveTar.launch("HASS_repacked.tar") } })
        root.addView(actionButton("فحص ملف TAR فقط") { runCatching { val m = readTar(contentResolver.openInputStream(selectedTar ?: error("اختر ملف TAR"))!!.use { it.readBytes() }); val xml = m.entries.firstOrNull { it.key.substringAfterLast('/').equals("firminfo.xml", true) }?.value ?: error("لم يتم العثور على firminfo.xml"); val entries = parseEntries(xml); entries.forEach { e -> val raw = findMember(m, e.name); val decoded = decompress(raw); check(e.cSize == null || e.cSize == raw.size.toLong()) { "حجم المضغوط غير مطابق: ${e.name}" }; check(e.cCrc == null || e.cCrc == crc16(raw)) { "CRC المضغوط غير مطابق: ${e.name}" }; check(e.size == null || e.size == decoded.size.toLong()) { "حجم BIN غير مطابق: ${e.name}" }; check(e.crc == null || e.crc == crc16(decoded)) { "CRC BIN غير مطابق: ${e.name}" } }; status.text = "سليم: تم فحص ${entries.size} ملف بنجاح" }.onFailure { showError(it) } })
        val note = TextView(this).apply { text = "ملاحظة: إعادة الضغط تنتج تدفق LZ متوافقاً حسب خوارزمية المشروع، لكن بايتات LZW وCRC المضغوط قد تختلف عن الأصل. لا يقوم التطبيق بتفليش اللوحة."; textSize = 13f; setTextColor(0xFF7A4A16.toInt()); setPadding(4, 18, 4, 10) }
        root.addView(note)
        status = TextView(this).apply { text = "جاهز"; textSize = 15f; setTextColor(0xFF174A2C.toInt()); setPadding(12, 16, 12, 16); setBackgroundColor(0xFFE4F1E8.toInt()) }
        root.addView(status)
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
    }
    private fun label(s:String)=TextView(this).apply { text=s; textSize=13f; setTextColor(0xFF475569.toInt()); setPadding(2,12,2,2) }
    private fun actionButton(s:String, click:()->Unit)=Button(this).apply { text=s; isAllCaps=false; textSize=15f; setOnClickListener { click() }; layoutParams=LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 } }
    private fun nameOf(uri:Uri)=uri.lastPathSegment?.substringAfterLast('/') ?: "ملف"
    private fun showError(t:Throwable) { status.text = "خطأ: ${t.message ?: t.javaClass.simpleName}" }
    private fun bytes(uri:Uri)=contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("تعذر قراءة الملف")

    private data class Entry(val name:String,val size:Long?,val crc:Int?,val cSize:Long?,val cCrc:Int?)
    private fun parseEntries(xml:ByteArray):List<Entry> {
        val doc=DocumentBuilderFactory.newInstance().apply { setFeature("http://apache.org/xml/features/disallow-doctype-decl",true) }.newDocumentBuilder().parse(ByteArrayInputStream(xml))
        val nodes=doc.getElementsByTagName("*"); val out= mutableListOf<Entry>()
        for(i in 0 until nodes.length) { val e=nodes.item(i) as Element; val a=e.attributes; fun get(vararg keys:String):String? { for(k in keys) if(a.getNamedItem(k)!=null) return a.getNamedItem(k).nodeValue; return null }; val n=get("Name","name","File","file") ?: continue; if(!n.endsWith(".lzw",true)) continue; fun hx(vararg k:String)=get(*k)?.trim()?.removePrefix("0x")?.toLongOrNull(16); out.add(Entry(n,hx("Size","size"),hx("Checksum","checksum")?.toInt(),hx("Compressed_Size","CompressedSize","compressed_size","compressedSize"),hx("Compressed_Checksum","CompressedChecksum","compressed_checksum","compressedChecksum")?.toInt())) }
        check(out.isNotEmpty()) { "لا توجد ملفات LZW في firminfo.xml" }; return out
    }
    private fun findMember(m:Map<String,ByteArray>, name:String):ByteArray { m[name]?.let{return it}; val x=m.filterKeys{it.substringAfterLast('/')==name.substringAfterLast('/')}; check(x.size==1){"الملف غير موجود أو الاسم مكرر: $name"}; return x.values.first() }
    private fun writeUnpackedZip(uri:Uri) {
        val map=readTar(bytes(selectedTar!!)); val xml=map.entries.firstOrNull{it.key.substringAfterLast('/').equals("firminfo.xml",true)}?.value ?: error("firminfo.xml غير موجود")
        val entries=parseEntries(xml); val stream=contentResolver.openOutputStream(uri) ?: error("تعذر إنشاء الملف")
        ZipOutputStream(stream).use { zip -> val report=StringBuilder("filename,compressed_size,compressed_crc,decoded_size,decoded_crc\n"); entries.forEach { e -> val raw=findMember(map,e.name); val decoded=decompress(raw); check(e.cSize==null||e.cSize==raw.size.toLong()){"Compressed_Size غير مطابق: ${e.name}"}; check(e.cCrc==null||e.cCrc==crc16(raw)){"Compressed_Checksum غير مطابق: ${e.name}"}; check(e.size==null||e.size==decoded.size.toLong()){"Size غير مطابق: ${e.name}"}; check(e.crc==null||e.crc==crc16(decoded)){"Checksum غير مطابق: ${e.name}"}; zip.putNextEntry(ZipEntry(e.name.substringAfterLast('/').substringBeforeLast('.')+".bin")); zip.write(decoded); zip.closeEntry(); report.append("${e.name},${raw.size},${hex(crc16(raw))},${decoded.size},${hex(crc16(decoded))}\n") }; zip.putNextEntry(ZipEntry("manifest.csv")); zip.write(report.toString().toByteArray()); zip.closeEntry() }
    }
    private fun writePackedTar(uri:Uri) {
        val raw=bytes(selectedBin!!); val lzw=compress(raw); check(decompress(lzw).contentEquals(raw)){"فشل اختبار فك الضغط بعد الضغط"}
        val template=selectedTar?.let{readTar(bytes(it))} ?: linkedMapOf(); val xmlEntry=template.entries.firstOrNull{it.key.substringAfterLast('/').equals("firminfo.xml",true)}
        val doc=if(xmlEntry!=null) DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(ByteArrayInputStream(xmlEntry.value)) else DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument().apply { appendChild(createElement("Firmware").also{it.setAttribute("TargetName","main")}) }
        val root=doc.documentElement; val nodes=doc.getElementsByTagName("*"); var target:Element?=null
        for(i in 0 until nodes.length){val e=nodes.item(i) as Element; val n=e.getAttribute("Name").ifEmpty{e.getAttribute("File")}; if(n.endsWith(".lzw",true)){target=e;break}}
        val outName=target?.getAttribute("Name")?.ifEmpty{target?.getAttribute("File")}?.ifEmpty{"firmware.lzw"} ?: "firmware.lzw"
        val e=target ?: doc.createElement("File").also{root.appendChild(it)}; e.setAttribute("Name",outName); e.setAttribute("Compressed_Size",lzw.size.toString(16).uppercase()); e.setAttribute("Compressed_Checksum",hex(crc16(lzw))); e.setAttribute("Size",raw.size.toString(16).uppercase()); e.setAttribute("Checksum",hex(crc16(raw))); root.setAttribute("FileCount",doc.getElementsByTagName("File").length.toString())
        val tf=TransformerFactory.newInstance().newTransformer().apply{setOutputProperty(OutputKeys.INDENT,"yes");setOutputProperty(OutputKeys.ENCODING,"UTF-8")}; val xb=ByteArrayOutputStream(); tf.transform(DOMSource(doc),StreamResult(xb))
        val output=linkedMapOf<String,ByteArray>(); template.forEach{(k,v)->if(!k.substringAfterLast('/').equals("firminfo.xml",true)&&!k.substringAfterLast('/').equals(outName.substringAfterLast('/'),true)&&k.endsWith(".lzw",true)) output[k]=v}; output[outName]=lzw; output["firminfo.xml"]=xb.toByteArray()
        contentResolver.openOutputStream(uri)?.use{writeTar(output,it)} ?: error("تعذر حفظ TAR")
    }

    private fun decompress(data:ByteArray):ByteArray { val out=ByteArrayOutputStream(); val hist=ByteArray(256); var w=0; var i=0; while(i<data.size){val b=data[i++].toInt() and 255; if(b!=0xB4){out.write(b);hist[w]=b.toByte();w=(w+1)and 255;continue}; check(i<data.size){"تدفق LZW مبتور"}; val d=data[i++].toInt()and 255; if(d==0){out.write(0xB4);hist[w]=0xB4.toByte();w=(w+1)and 255;continue}; check(i<data.size){"طول النسخ مفقود"}; val n=data[i++].toInt()and 255; var src=(w-d+256)and 255; repeat(n){val v=hist[(src+it)and 255];out.write(v.toInt()and 255);hist[w]=v;w=(w+1)and 255} };return out.toByteArray() }
    private fun compress(data:ByteArray):ByteArray { val out=ByteArrayOutputStream(); val h=ByteArray(256); var w=0; var i=0; fun lit(b:Int){if(b==0xB4){out.write(0xB4);out.write(0)}else out.write(b);h[w]=b.toByte();w=(w+1)and 255}; fun copy(d:Int,n:Int){out.write(0xB4);out.write(d);out.write(n);val src=(w-d+256)and 255;repeat(n){val v=h[(src+it)and 255];h[w]=v;w=(w+1)and 255}}
        while(i<data.size){var bd=0;var bc=0;val max=minOf(255,data.size-i);for(d in 1..255){val s=(w-d+256)and 255;if(h[s]!=data[i])continue;val gen=ArrayList<Byte>();var c=0;while(c<max){val v=if(c<d)h[(s+c)and 255] else gen[c-d];if(v!=data[i+c])break;gen.add(v);c++};if(c>bc){bc=c;bd=d;if(bc==max)break}};var cost=0;for(k in 0 until bc)cost+=if((data[i+k].toInt()and 255)==0xB4)2 else 1;if(bc>=4&&cost>3){copy(bd,bc);i+=bc}else{lit(data[i++].toInt()and 255)}};return out.toByteArray() }
    private fun crc16(b:ByteArray):Int { var c=0xFFFF;for(v0 in b){c=c xor ((v0.toInt()and 255) shl 8);repeat(8){c=if((c and 0x8000)!=0)((c shl 1) xor 0x1021)and 0xFFFF else (c shl 1)and 0xFFFF}};return c }
    private fun hex(v:Int)="%04X".format(v)

    // Minimal POSIX TAR reader/writer. Rejects traversal paths and ignores non-file entries.
    private fun readTar(b:ByteArray):LinkedHashMap<String,ByteArray>{val m=linkedMapOf<String,ByteArray>();var p=0;while(p+512<=b.size){val h=b.copyOfRange(p,p+512);if(h.all{it.toInt()==0})break;val name=String(h,0,100).trimEnd('\u0000');val prefix=String(h,345,155).trimEnd('\u0000');val full=if(prefix.isNotEmpty())"$prefix/$name" else name;check(!full.startsWith("/")&&!full.split('/').contains("..")){"مسار TAR غير آمن"};val size=String(h,124,12).trim().trim('\u0000').toLongOrNull(8)?:0;val type=h[156].toInt().toChar();p+=512;check(size>=0&&p+size<=b.size){"حجم عضو TAR غير صحيح"};if(type=='0'||type=='\u0000')m[full]=b.copyOfRange(p,p+size.toInt());p+=(((size+511)/512)*512).toInt()};return m }
    private fun writeTar(m:Map<String,ByteArray>,o:OutputStream){for((name,data) in m){val h=ByteArray(512);put(h,0,100,name);put(h,100,8,"0000644\u0000");put(h,108,8,"0000000\u0000");put(h,116,8,"0000000\u0000");put(h,124,12,"%011o\u0000".format(data.size));put(h,136,12,"00000000000\u0000");for(i in 148..155)h[i]=32;h[156]='0'.code.toByte();put(h,257,6,"ustar\u0000");put(h,263,2,"00");val sum=h.sumOf{it.toInt()and 255};put(h,148,8,"%06o\u0000 " .format(sum));o.write(h);o.write(data);val pad=(512-data.size%512)%512;if(pad>0)o.write(ByteArray(pad))};o.write(ByteArray(1024));o.flush()}
    private fun put(b:ByteArray,off:Int,len:Int,s:String){val x=s.toByteArray(Charsets.US_ASCII);System.arraycopy(x,0,b,off,minOf(len,x.size))}
}
